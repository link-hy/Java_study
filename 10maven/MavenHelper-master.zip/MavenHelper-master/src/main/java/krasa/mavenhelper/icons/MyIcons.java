package krasa.mavenhelper.icons;

import com.intellij.openapi.util.IconLoader;

public class MyIcons {
	public static final javax.swing.Icon ICON = IconLoader.getIcon("/krasa/mavenhelper/icons/debug.svg");
	public static final javax.swing.Icon RUN_MAVEN_ICON = IconLoader.getIcon("/krasa/mavenhelper/icons/runMaven.svg");
	public static final javax.swing.Icon PHASES_CLOSED = IconLoader.getIcon("/krasa/mavenhelper/icons/phasesClosed.svg");
	public static final javax.swing.Icon PLUGIN_GOAL = IconLoader.getIcon("/krasa/mavenhelper/icons/pluginGoal.svg");
	public static final javax.swing.Icon OPEN_TERMINAL = IconLoader.getIcon("/krasa/mavenhelper/icons/OpenTerminal.svg");
	public static final javax.swing.Icon MAVEN_LOGO = IconLoader.getIcon("/krasa/mavenhelper/icons/mavenLogo.svg");

}
